impacts <-
function(results, p_values=FALSE){
  if (attr(results,"reg_type")=="alr_x_reg"){return(alr_x_impacts(results))}
  if (attr(results,"reg_type")=="alr_y_reg"){return(alr_y_impacts(results))}
  if (attr(results,"reg_type")=="alr_yx_reg"){return(alr_yx_impacts(results))}
  if (attr(results,"reg_type")=="ilr_x_reg"){
    imps_original = ilr_x_impacts(results)
    if (p_values==F){return(imps_original)}
    imps = imps_original
    ss = sd_se_x(results)
    signs = imps
    for (j in 1:dim(imps)[2]){
      for (i in 1:dim(imps)[1]){
        val = imps[i,j]
        tt = val/ss[i,j]
        pval = 1+pnorm(-abs(tt))-pnorm(abs(tt))
        if ((pval>0.05)&(pval<0.10)){
          signs[i,j]  = "*  "
        }
        if ((pval<0.05)&(pval>0.01)){
          signs[i,j]  = "** "
        }
        if (pval<0.01){
          signs[i,j]  = "***"
        }
        else{
          signs[i,j]  = "   "
        }
      }
    }
    for (i in (dim(signs)[2]):1){
      orignames = colnames(imps)
      nnames_i = "   "
      if (i==dim(imps)[2]){
        newnames  = c(orignames[1:i],nnames_i)
        newmat    = cbind(imps[,1:i],signs[,i])
      }
      else{
        newnames  = c(orignames[1:i],nnames_i,orignames[(i+1):length(orignames)])
        newmat    = cbind(imps[,1:i],signs[,i],imps[,(i+1):(dim(imps)[2])])
      }
      imps = newmat
      orignames = newnames
      colnames(imps) = orignames
    }
    print(tidy(imps), quote=FALSE)
    return(cat("\n"))
  }
  if (attr(results,"reg_type")=="ilr_y_reg"){return(ilr_y_impacts(results))}
  if (attr(results,"reg_type")=="ilr_yx_reg"){return(ilr_yx_impacts(results))}
  else{stop("Input in 'impacts()' function is not a valid output of one of the regression functions.")}
}
