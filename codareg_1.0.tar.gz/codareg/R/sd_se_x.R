sd_se_x <-
function(reg_results){
  constant = reg_results$constant
  xdim = reg_results$xdim
  
  if (attr(reg_results,"reg_type") == "ilr_x_reg"){
  imp_results = ilr_x_impacts(reg_results)
  V = attr(reg_results$X_coord,"contrast")
  }

  if (attr(reg_results,"reg_type") == "alr_x_reg"){
  imp_results = alr_x_impacts(reg_results)}
  
  y_parts = dim(imp_results)[2]
  nrows = dim(imp_results)[1]
  dimres = dim(reg_results$Bcoord_cov)[1]
  matsds = reg_results$Bcoord_cov
  x_parts = 0
  for (k in 1:length(xdim)){
    x_parts = x_parts + xdim[[k]][1] - 1
  }
  
  matl = dimres / y_parts
  matlist = list()
  t=1
  
  for (k in 1:y_parts){
    matlist[[k]] = as.matrix(matsds[t:(t+matl-1),t:(t+matl-1)])
    if (constant){matlist[[k]]=matlist[[k]][-1,-1]}
    matlist[[k]] = matlist[[k]][1:x_parts,1:x_parts]
    t=t+matl
  }
  
  sds = c()
  reds = list()
  for (k in 1:y_parts){
    h=1
    for (j in 1:length(xdim)){
      fin = h+xdim[[j]]-2
      redmat = as.matrix(matlist[[k]][h:fin,h:fin])
      if (attr(reg_results,"reg_type") == "alr_x_reg"){
        var_j = t(F_D(xdim[[j]]))%*%redmat%*%(F_D(xdim[[j]]))}
      if (attr(reg_results,"reg_type") == "ilr_x_reg"){
        var_j = V[[j]]%*%redmat%*%t(V[[j]])}
      sds = c(sds,sqrt(diag(var_j)))
      h=h+xdim[[j]]-1
    }
  }
  result_mat = t(matrix(sds, y_parts,nrows, byrow=T))
  return(result_mat)
}
