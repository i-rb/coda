ilr_y_reg <-
function(Y,X,V=list(matrix()),constant=TRUE){
  if (constant){x_col_names = c("intercept")}
  else{x_col_names = c()}
  
  for (i in 1:length(X)){
    if (is.null(colnames(X[[i]]))){
      for (j in 1:(dim(X[[i]])[2])){
        x_col_names = c(x_col_names, paste("X_",i,"_",j,sep=""))
      }
    }
    else{x_col_names = c(x_col_names,colnames(X[[i]]))}
  }
  
  if (is.null(colnames(Y))){
    y_col_names = c()
    for (i in 1:(dim(Y)[2])){
      y_col_names = c(y_col_names, paste("Y_",i,sep=""))
    }
  }
  else{y_col_names = colnames(Y)}
  
  tx = matrix(numeric(dim(X[[1]])[1]))+1 # X = tx as it is already in coord.
  for (i in 1:length(X)){
    tx = cbind(tx,X[[i]])
    }
  if (constant==FALSE){ # should remove the vector of ones if no constant is required
    tx=tx[,-1]
  }
  
  # transform Y to coordinates
  if (!is.na(V[[1]][1,1])){ # if V specified as argument
    ty = ilr(Y,V[[1]])
  }
  
  else{
    V=list(V_D(dim(Y)[2])) # if V not specified as argument
    ty=ilr(Y,V[[1]])}
  
  if (sum(is.na(ty))>0){stop("There are NAs in the Y variable.")}
  if (sum(is.na(tx))>0){stop("There are NAs in the X variable.")}
  
  Bstar = mlm(ty,tx)
  bcov = b_cov(tx,ty,Bstar) 
  Bs = t(matrix(numeric(dim(Y)[2])))
  
  h=1
  if (constant==TRUE){
    h=2
    b0=inverseilr(t(Bstar[1,]),V[[1]])
    Bs = rbind(Bs, b0)
  }
  if (!is.na(X[[1]][1,1])){
    for (i in 1:length(X)){
      dimx = dim(X[[i]])[2]
      matrix_x = Bstar[h:(h+dimx-1),]
      if (h==(h+dimx-1)){matrix_x = t(matrix(Bstar[h,]))}
      if (h!=(h+dimx-1)){matrix_x = Bstar[h:(h+dimx-1),]} # it is non comp, it does not lose a dimension in the transformation
      h=h+dimx
      c_k = inverseilr(matrix_x, V[[1]])
      Bs = rbind(Bs, c_k)
    }
  }
  Bs = Bs[-1,]
  attr(Bstar,"space")="ilr_coord"
  attr(Bstar,"contrast") = V
  
  attr(tx,"space") = "ilr_coord"
  attr(tx,"contrast") = NaN
  

  
  fittedvalues = tx%*%Bstar
  resid = ty- fittedvalues
  attr(resid,"space") = NULL
  attr(resid,"contrast") = NULL
  colnames(Bs) = y_col_names
  rownames(Bs) = x_col_names
  attr(Bs,"space")="simplex"
  
  list_return = list(Y_coord = ty, X_coord = tx, constant = constant, B_coord = Bstar, B_simplex = Bs, Bcoord_cov=bcov, residuals_coord = resid, fitted_v_coord = fittedvalues)
  attr(list_return, "reg_type") = "ilr_y_reg"
  
  return(list_return)
}
