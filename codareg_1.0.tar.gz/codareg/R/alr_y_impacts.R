alr_y_impacts <-
function(results){ 
  constant = results$constant
  Bcoord = results$B_coord
  coln = colnames(results$B_simplex)
  rown = rownames(results$B_simplex)
  R = attr(results$Y_coord, "reference")
  xcoord = results$X_coord
  EYcoord = xcoord%*%Bcoord
  Re=dim(EYcoord)[2]+1
  EYsimpl = inversealr(EYcoord,Re)
  D = dim(EYcoord)[2]+1
  impacts=list()
  for (i in 1:(dim(EYsimpl)[1])){
    Wi = diag(D) - matrix(1,D,1)%*%t(EYsimpl[i,]) 
    Wistar = Wi%*%P_D(D) 
    tempres = t(Wistar%*%t(Bcoord))
    tempres = inv_permutation_D(tempres,R)
    colnames(tempres) = coln
    rownames(tempres) = rown
    if (constant){
      if (dim(tempres)[1]==2){ 
          tempres = t(as.matrix(tempres)[-1,])
          rownames(tempres) = c(rown[[2]])
        }
        else{
          tempres = tempres[-1,]
        }
      }
    
    impacts[[i]] = tempres
  }
  return(impacts)
}
