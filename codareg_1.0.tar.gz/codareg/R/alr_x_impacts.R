alr_x_impacts <-
function(results){ # the unique argument is the named list that comes from the ilr_yx_reg function
    B = results$B_coord
    xnames = rownames(results$B_simplex)
    ynames = colnames(results$B_simplex)
    constant = results$constant
    if (constant){xnames = xnames[-1]}
    listxdim = results$xdim
    R = attr(B,"reference")
    if (constant){
      if (dim(B)[2]==1){B=matrix(B[-1,])}
      else{
        B = B[-1,]
      }
    }
    h=1
    impacts=list()
    for (i in 1:length(R)){
      dimx = listxdim[[i]]
      if (is.null(dim(B))){B=t(matrix(B))}
      bstar = B[h:(h+dimx-2),]
      h=h+dimx-1
      impact_i = t(F_D(dimx))%*%bstar
      impacts[[i]]= t(inv_permutation_D(t(impact_i),R[[i]]))
    }
    cc=1
    for (k in (1:length(impacts))){
      val = impacts[[k]]
      ldimx = dim(val)[1]
      colnames(val) = ynames
      rownames(val) = xnames[cc:(cc+ldimx-1)]
      cc = cc + ldimx
      impacts[[k]] = val
    }
    ## part of pooling impacts into a single matrix 
    impacts_mat = impacts[[1]]
    if (length(impacts)>1){
      for (j in (2:length(impacts))){
        impacts_mat = rbind(impacts_mat, impacts[[j]])
      }
    }
    return(impacts_mat)
}
