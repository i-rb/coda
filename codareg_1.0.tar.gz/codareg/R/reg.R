reg <-
function(dataset, formula, transformation = "ILR", V=list(matrix()), R=list(NULL), pres=FALSE, simplex_pvalues=FALSE, B=1000, seed=31000){
  reg_res = inner_reg(dataset = dataset, formula = formula, transformation = transformation, V=V, R=R)
  if (!pres){return(reg_res)}
  input = check_formula(dataset, formula)
  model_type = input$model_type
  Bs = reg_res$B_simplex
  Bstar = reg_res$B_coord
  bcov = reg_res$Bcoord_cov
  tx = reg_res$X_coord
  ty = reg_res$Y_coord
  resid = reg_res$residuals_coord
  Y = input$Y
  X = input$X
  Z = input$Z
  constant=input$constant
  
  dfsimplex = data.frame(Bs)
  name=c()
  for (i in 1:(dim(Y)[2])){
    name = c(name, paste("Y_", i, sep=""))
  }
  colnames(dfsimplex)=name
  
  rname = c()
  if (constant){rname = c(rname, "intercept")}
  for (i in 1:length(X)){
    for (j in 1:(dim(X[[i]])[2])){
      rname = c(rname, paste("X",i,j,sep="_"))
    }
  }
  
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      for (j in 1:(dim(Z[[i]])[2])){
         rname = c(rname, paste("Z",i,j,sep="_"))
      }
    }
  }
  
  rownames(dfsimplex)=rname
  
  if (model_type=="y_reg"){pp=1}
  if (model_type=="yx_reg"){pp=1}
  if (model_type=="x_reg"){pp=0}
  
  cnames = c()
  for (i in (1:(dim(Y)[2]-pp))){
    if (transformation=="ILR"){
      cnames = c(cnames, paste("Yilr_",i,sep=""))
      cnames = c(cnames, paste("(sd_Yilr_",i,")",sep=""))}
    if (transformation=="ALR"){
      cnames = c(cnames, paste("Yalr_",i,sep=""))
      cnames = c(cnames, paste("(sd_Yalr_",i,")",sep=""))}
  }
  
  if (model_type=="y_reg"){qq=0}
  if (model_type=="yx_reg"){qq=1}
  if (model_type=="x_reg"){qq=1}
  
  rname = c()
  if (constant){rname = c(rname, "intercept")}
  hhhh = 1
  for (i in 1:length(X)){
    for (j in 1:(dim(X[[i]])[2]-qq)){
      if (transformation=="ILR"){
        if (model_type=="y_reg"){rname = c(rname, paste("X",hhhh,sep="_"))}
        else{
        rname = c(rname, paste("Xilr",i,j,sep="_"))}}
      if (transformation=="ALR"){
        if (model_type=="y_reg"){rname = c(rname, paste("X",hhhh,sep="_"))}
        else{
        rname = c(rname, paste("Xalr",i,j,sep="_"))}}
    }
    hhhh=hhhh+1
      }
  
  if (!is.na(Z[[1]][1,1])){
    ccc=1
    for (i in 1:length(Z)){
      for (j in 1:(dim(Z[[i]])[2])){
        if (transformation=="ALR"){
          rname = c(rname, paste("Z",ccc,sep="_"))
        }
        if (transformation=="ILR"){
          rname = c(rname, paste("Z",ccc,sep="_"))
        }
        ccc=ccc+1
      }
    }
  }

  
  # B star and sds
  dfilr = data.frame(Bstar)
  
  # sds
  dimilr = dim(Y)[2]-pp
  nc = dim(dfilr)[1]
  for (i in dimilr:1){
    if (i==dimilr){dfilr = cbind(dfilr,matrix(nrow=nc))}
    else{
      dfilr = cbind(dfilr[,1:i],matrix(nrow=nc),dfilr[,(i+1):(dim(dfilr)[2])])
    }
  }
  
  dfilr = t(dfilr)
  
  for (i in 1:(dim(bcov)[1])){
    dfilr[2*i] = sqrt(bcov[i,i]) # standard deviation as sqrt of var
  }
  dfilr = t(dfilr)
  
  rownames(dfilr) = rname
  colnames(dfilr) = cnames
  
  ilr_pvals = matrix(0,dim(dfilr)[1],dim(dfilr)[2]/2)
  cc=0
  for (j in seq(1,dim(dfilr)[2],2)){
    cc=cc+1
    t_j = dfilr[,j]/dfilr[,j+1]
    for (i in 1:(dim(dfilr)[1])){
      pval = pnorm(-abs(t_j[[i]]),mean=0,sd=1)+(1-pnorm(abs(t_j[[i]]),mean=0,sd=1))
      if (is.na(pval)){ilr_pvals[i,cc]  = " - "}
      else{
        if ((pval>0.05)&(pval<0.10)){
          ilr_pvals[i,cc]  = "*  "
        }
        if ((pval<0.05)&(pval>0.01)){
          ilr_pvals[i,cc]  = "** "
        }
        if (pval<0.01){
          ilr_pvals[i,cc]  = "***"
        }
        else{
          ilr_pvals[i,cc]  = "   "
        }
      }
    }
  }
  
  for (i in dim(ilr_pvals)[2]:1){
    orignames = colnames(dfilr)
    nnames_i = "   "
    if (i==dim(ilr_pvals)[2]){
      newnames  = c(orignames[1:(2*i)],nnames_i)
      newmat    = cbind(dfilr[,1:(2*i)],ilr_pvals[,i])
    }
    else{
      newnames  = c(orignames[1:(2*i)],nnames_i,orignames[(2*i+1):length(orignames)])
      newmat    = cbind(dfilr[,1:(2*i)],ilr_pvals[,i],dfilr[,(2*i+1):(dim(dfilr)[2])])
    }
    dfilr = newmat
    orignames = newnames
    colnames(dfilr) = orignames
  }
    if (simplex_pvalues=="bootstrap"){
      sigmat = dfsimplex
      if (model_type=="y_reg"){pvals = p_values_coef(dataset = dataset,formula = formula,transformation = transformation,V=V,R=R,B=B,seed=seed)}
      if (model_type=="yx_reg"){pvals = p_values_coef(dataset = dataset,formula = formula,transformation = transformation,V=V,R=R,B=B,seed=seed)}
      if (model_type=="x_reg"){pvals = p_values_coef(dataset = dataset,formula = formula,transformation = transformation,V=V,R=R,B=B,seed=seed)}
      for (i in 1:(dim(dfsimplex)[1])){
        for (j in 1:(dim(dfsimplex)[2])){
          val = dfsimplex[i,j]
          pval = pvals[i,j]
          if (is.na(pval)){sigmat[i,cc]  = " - "}
          else{
            if ((pval>0.05)&(pval<0.10)){
              sigmat[i,j] = "*  "
            }
            if ((pval<=0.05)&(pval>0.01)){
              sigmat[i,j] = "** "
            }
            if (pval<=0.01){
              sigmat[i,j] = "***"
            }
            else{
              sigmat[i,j] = "   "
            }
          }
        }
      }
    }
    
  colnames(dfsimplex) = colnames(Bs)
  rownames(dfsimplex) = rownames(Bs)
  
  if (simplex_pvalues=="bootstrap"){
    for (i in dim(sigmat)[2]:1){
      orignames = colnames(dfsimplex)
      nnames_i = "   "
      if (i==dim(sigmat)[2]){
        newnames  = c(orignames[1:i],nnames_i)
        newmat    = cbind(dfsimplex[,1:i],sigmat[,i])
      }
      else{
        newnames  = c(orignames[1:i],nnames_i,orignames[(i+1):length(orignames)])
        newmat    = cbind(dfsimplex[,1:i],sigmat[,i],dfsimplex[,(i+1):(dim(dfsimplex)[2])])
      }
      dfsimplex = newmat
      orignames = newnames
      colnames(dfsimplex) = orignames
    }
  }
  if (transformation=="ILR"){
    arg4 = "     B* (COEF. and SD IN THE ILR SPACE):    "
  }
  if (transformation=="ALR"){
    arg4 = "     B* (COEF. and SD IN THE ALR SPACE):    "
  }
  arg1 = "      B (COEFFICIENTS IN THE SIMPLEX):      "
  arg2 = as.matrix(dfsimplex)
  arg3 = "--------------------------------------------"
  arg5 = as.matrix(dfilr)
  arg6 = "--------------------------------------------"
  arg7 = paste("n obs  : ", dim(tx)[1], sep="")
  arg8 = paste("SSR    : ", sum(resid^2), sep="") # sum of squared residuals
  cat(arg1,"\n")
  print(arg2,quote=FALSE)
  cat(arg3,"\n", arg4,"\n")
  print(tidy(arg5),quote=FALSE)
  cat(arg6,"\n", arg7,"\n", arg8,"\n")
}
