tidy <-
function(matrix, dig=14){
  for (j in 1:dim(matrix)[2]){
    if ((substr(matrix[1,j],1,1)!=" ")&(substr(matrix[1,j],1,1)!="*")){
      for (i in 1:dim(matrix)[1]){
        if (substr(matrix[i,j],1,1) != "-"){
          matrix[i,j] = paste(" ",matrix[i,j], sep="")
        }
        matrix[i,j] = substr(matrix[i,j],1,dig)
      }
    }
  }
  return(matrix)
}
