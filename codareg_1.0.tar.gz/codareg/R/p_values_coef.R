p_values_coef <-
function(dataset, formula, transformation = "ILR", V=list(matrix()), R=list(NULL), B=1000, seed=31000){
  input = check_formula(dataset,formula)
  if (input$model_type=="x_reg"){
    Y=input$Y
    X=input$X
    Z=input$Z
    constant = input$constant
    results = list()
    set.seed(seed)
    for (b in 1:B){
      ids <- sample(x=nrow(dataset), size=dim(dataset)[1], replace=T)
      sample_b <- dataset[ids,]
      rownames(sample_b) = NULL
      coefs_b = inner_reg(dataset = sample_b, formula = formula, transformation = transformation, V=V, R=R)$B_simplex
      results[[b]] = coefs_b
    }
    pvals = results[[1]]
    
    compare = matrix(0, dim(results[[1]])[1], dim(results[[1]])[2])
    h=1
    if (constant){
      compare[1,] = numeric(dim(compare)[2])
      h=2
    }
    for (elem in X){
      dimxx = dim(elem)[2]
      compare[h:(h+dimxx-1),] = matrix(1/dimxx, dim(Y)[2], dimxx)
    }
    
    attr(pvals,"space")=NULL
    for (i in 1:(dim(pvals)[1])){
      for (j in 1:(dim(pvals)[2])){
        dist = c()
        for (b in 1:B){
          dist = c(dist, results[[b]][i,j])
        }
        toc = compare[i,j]
        lowers = sum(dist[!is.na(dist)]<toc)/sum(!is.na(dist))
        pvals[i,j] = 2*min(lowers,1-lowers)
      }
    }
    return(pvals)
  }
  else{
    results = list()
    inputinput = check_formula(dataset,formula)
    model_type = inputinput$model_type
    X = inputinput$X
    dim_x = dim(X[[1]])[2]
    if (inputinput$constant == T){dim_x = dim_x + 1}
    set.seed(seed)
    for (b in 1:B){
      ids <- sample(x=nrow(dataset), size=dim(dataset)[1], replace=T)
      sample_b <- dataset[ids,]
      rownames(sample_b) = NULL
      coefs_b = inner_reg(dataset = sample_b, formula = formula, transformation = transformation, V=V, R=R)$B_simplex
      results[[b]] = coefs_b
    }
    pvals = results[[1]]
    attr(pvals,"space")=NULL
    P = dim(pvals)[2]
    
    for (i in 1:(dim(pvals)[1])){
      dp=0
      if (model_type=="y_reg"){dp = 1/P}
      if (i>dim_x){dp=1/P}
      if (i==1){
        if (inputinput$constant){
          dp=1/P
        }
      }
      for (j in 1:(dim(pvals)[2])){
        dist = c()
        for (b in 1:B){
          dist = c(dist, results[[b]][i,j])
        }
        lowers = sum(dist<(dp))/B
        pvals[i,j] = 2*min(lowers,1-lowers)
      }
    }
    return(pvals)
  }
}
