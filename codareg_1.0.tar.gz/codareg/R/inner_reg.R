inner_reg <-
function(dataset, formula, transformation = "ILR", V=list(matrix()), R=list(NULL)){
  input = check_formula(dataset, formula)
  Y = input$Y
  X = input$X
  Z = input$Z
  constant = input$constant
  model_type = input$model_type
  if (transformation == "ILR"){
    if (model_type == "yx_reg"){
      return(ilr_yx_reg(Y=Y,X=X,Z=Z,V=V,constant = constant))
    }
    if (model_type == "x_reg"){
      return(ilr_x_reg(Y=Y,X=X,Z=Z,V=V,constant=constant))
    }
    if (model_type == "y_reg"){
      return(ilr_y_reg(Y=Y,X=X,V=V,constant=constant))
    }
  }
  if (transformation == "ALR"){
    if (model_type == "yx_reg"){
      return(alr_yx_reg(Y=Y,X=X,Z=Z,R=R,constant=constant))
    }
    if (model_type == "x_reg"){
      return(alr_x_reg(Y=Y,X=X,Z=Z,R=R,constant=constant))
    }
    if (model_type == "y_reg"){
      return(alr_y_reg(Y=Y,X=X,R=R,constant=constant))
    }
  }
}
