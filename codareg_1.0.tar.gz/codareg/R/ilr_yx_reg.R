ilr_yx_reg <-
function(Y,X,Z=list(matrix()),V=list(matrix()),constant=TRUE){
  if (constant){x_col_names = c("intercept")}
  else{x_col_names = c()}
  
  for (i in 1:length(X)){
    if (is.null(colnames(X[[i]]))){
      for (j in 1:(dim(X[[i]])[2])){
        x_col_names = c(x_col_names, paste("X_",i,"_",j,sep=""))
      }
    }
    else{x_col_names = c(x_col_names,colnames(X[[i]]))}
  }
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      if (is.null(colnames(Z[[i]]))){
      for (j in 1:(dim(Z[[i]])[2])){
        x_col_names = c(x_col_names, paste("Z_",i,"_",j,sep=""))
      }
    }
      else{x_col_names = c(x_col_names,colnames(Z[[i]]))
      }
    }
  }
  
  if (is.null(colnames(Y))){
    y_col_names = c()
    for (i in 1:(dim(Y)[2])){
      y_col_names = c(y_col_names, paste("Y_",i,sep=""))
    }
  }
  else{y_col_names = colnames(Y)}
  
  input = var2ilr(Y,X,Z,V=V,constant = constant)
  ty = input$Y
  tx = input$X

  if (sum(is.na(ty))>0){stop("There are NAs in the Y variable.")}
  if (sum(is.na(tx))>0){stop("There are NAs in the X variable.")}
  
  constant = input$constant
  V = input$V

  Bstar = mlm(ty,tx)
  bcov = b_cov(tx,ty,Bstar)
  Bs = t(matrix(numeric(dim(Y)[2])))
  
  h=1
  if (constant==TRUE){
    h=2
    b0=inverseilr(t(Bstar[1,]),V[[1]])
    Bs = rbind(Bs, b0)
  }
  for (i in 1:length(X)){
    if (is.null(attr(X[[i]],"space"))){dimx = dim(X[[i]])[2]} #number of parts of this variable i of X D parts --> D-1 param in the ilr 
    if (!is.null(attr(X[[i]],"space"))){
      if (attr(X[[i]],"space")=="simplex"){
        dimx = dim(X[[i]])[2]
      }
      else{dimx = dim(X[[i]])[2]+1}
    }
    if (h==(h+dimx-2)){matrix_x = t(matrix(Bstar[h,]))}
    if (h!=(h+dimx-2)){matrix_x = Bstar[h:(h+dimx-2),] }
    B_q = V[[1]]%*%t(matrix_x)%*%t(V[[i+1]])
    Bs= rbind(Bs, t(B_q))
    h=h+dimx-1
  }
  
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      dimz = dim(Z[[i]])[2]
      if (h==(h+dimz-1)){matrix_z = t(matrix(Bstar[h,]))}
      if (h!=(h+dimz-1)){matrix_z = Bstar[h:(h+dimz-1),]} # it is non comp, it does not lose a dimension in the transformation
      h=h+dimz
      c_k = inverseilr(matrix_z, V[[1]])
      Bs = rbind(Bs, c_k)
    }
  }
  Bs = Bs[-1,]
  attr(Bstar,"space")="ilr_coord"
  attr(Bstar,"contrast") = V
  
  attr(tx,"space") = "ilr_coord"
  attr(tx,"contrast") = V[-1]
  
  
  fittedvalues = tx%*%Bstar
  resid = ty- fittedvalues
  attr(resid,"space") = NULL
  attr(resid,"contrast") = NULL
  colnames(Bs) = y_col_names
  rownames(Bs) = x_col_names
  attr(Bs,"space")="simplex"
  
  reslist = list(Y_coord = ty, X_coord = tx, constant = constant, B_coord = Bstar, B_simplex = Bs , Bcoord_cov=bcov, residuals_coord = resid, fitted_v_coord = fittedvalues)
  attr(reslist,"reg_type") = "ilr_yx_reg"
  
  return(reslist) 
}
