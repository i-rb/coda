p_values_se <-
function(dataset, formula, observation, transformation = "ILR", V=list(matrix()), R=list(NULL), B=1000, seed=31000){
  results = list()
  set.seed(seed)
  for (b in 1:B){
    ids <- sample(x=nrow(dataset), size=dim(dataset)[1]-1, replace=T)
    ids = c(observation,ids)
    sample_b <- dataset[ids,]
    rownames(sample_b) = NULL
    impacts_i = impacts(inner_reg(dataset = sample_b, formula = formula, transformation = transformation, V=V, R=R))[[1]]
    results[[b]] = impacts_i
  }
  rimpacts = results[[1]]
  for (i in 1:(dim(rimpacts)[1])){
    for (j in 1:(dim(rimpacts)[2])){
      dist = c()
      for (b in 1:B){
        dist = c(dist, results[[b]][i,j])
      }
      lowers = sum(dist<0)/B
      rimpacts[i,j] = 2*min(lowers,1-lowers)
    }
  }
  return(rimpacts)
}
