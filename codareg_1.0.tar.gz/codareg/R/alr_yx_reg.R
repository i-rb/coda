alr_yx_reg <-
function(Y,X,Z=list(matrix()),R=list(NULL),constant=TRUE){
  
  if (constant){x_col_names = c("intercept")}
  else{x_col_names = c()}
  
  for (i in 1:length(X)){
    if (is.null(colnames(X[[i]]))){
      for (j in 1:(dim(X[[i]])[2])){
        x_col_names = c(x_col_names, paste("X_",i,"_",j,sep=""))
      }
    }
    else{x_col_names = c(x_col_names,colnames(X[[i]]))}
  }
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      if (is.null(colnames(Z[[i]]))){
      for (j in 1:(dim(Z[[i]])[2])){
        x_col_names = c(x_col_names, paste("Z_",i,"_",j,sep=""))
      }
    }
      else{x_col_names = c(x_col_names,colnames(Z[[i]]))
      }
    }
  }
  
  if (is.null(colnames(Y))){
    y_col_names = c()
    for (i in 1:(dim(Y)[2])){
      y_col_names = c(y_col_names, paste("Y_",i,sep=""))
    }
  }
  else{y_col_names = colnames(Y)}
  
  
  if (!is.null(R[[1]])){
    Y=permutation_D(Y,R[[1]])
    for (j in 1:length(X)){
      X[[j]]=permutation_D(X[[j]],R[[j+1]])
    input = var2alr(Y,X,Z,constant=constant)
    }
  }
  else{
    input = var2alr(Y,X,Z,constant=constant)
    R=input$R
  }
  
  ty = input$Y
  tx = input$X
  if (sum(is.na(ty))>0){stop("There are NAs in the Y variable.")}
  if (sum(is.na(tx))>0){stop("There are NAs in the X variable.")}
  dimy = dim(ty)[2]+1
  constant = input$constant

  Bstar = mlm(ty,tx)
  bcov = b_cov(tx,ty,Bstar)
  Bs = t(matrix(numeric(dim(Y)[2])))
  
  h=1
  if (constant==TRUE){
    h=2
    b0=inversealr(t(Bstar[1,]),R[[1]])
    Bs = rbind(Bs, b0)
  }
  for (i in 1:length(X)){
    if (is.null(attr(X[[i]],"space"))){dimx = dim(X[[i]])[2]} #number of parts of this variable i of X D parts --> D-1 param in the alr 
    if (!is.null(attr(X[[i]],"space"))){
      if (attr(X[[i]],"space")=="simplex"){
        dimx = dim(X[[i]])[2]
      }
      else{dimx = dim(X[[i]])[2]+1}
    }
    if (h==(h+dimx-2)){matrix_x = t(matrix(Bstar[h,]))}
    if (h!=(h+dimx-2)){matrix_x = Bstar[h:(h+dimx-2),] }
    B_q = K_D(dimy)%*%t(matrix_x)%*%F_D(dimx)
    B_q = t(B_q)
    B_q = t(inv_permutation_D(t(B_q),R[[i+1]]))
    Bs= rbind(Bs, B_q)
    h=h+dimx-1
  }

  Bs = Bs[-1,]
  if (constant){
    Bsintercept = Bs[1,]
    Bs = Bs[-1,]
  }
  Bs = inv_permutation_D(Bs,R[[1]])
  if (constant){
    Bs = rbind(Bsintercept,Bs)
  }
  
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      dimz = dim(Z[[i]])[2]
      if (h==(h+dimz-1)){matrix_z = t(matrix(Bstar[h,]))}
      if (h!=(h+dimz-1)){matrix_z = Bstar[h:(h+dimz-1),]} # it is non comp, it does not lose a dimension in the transformation
      h=h+dimz
      c_k = inversealr(matrix_z, R[[1]]) 
      Bs = rbind(Bs, c_k)
    }
  }

  
  attr(Bstar,"space")="alr_coord"
  attr(Bstar,"reference") = R
  
  attr(tx,"space") = "alr_coord"
  attr(tx,"reference") = R[-1]
  
  fittedvalues = tx%*%Bstar
  resid = ty- fittedvalues
  attr(resid,"space") = NULL
  attr(resid,"contrast") = NULL
  
  rownames(Bs) = x_col_names
  colnames(Bs) = y_col_names
  attr(Bs,"space")="simplex"
  
  reslist = list(Y_coord = ty, X_coord = tx, constant = constant, B_coord = Bstar, B_simplex = Bs , Bcoord_cov=bcov, residuals_coord = resid, fitted_v_coord = fittedvalues)
  attr(reslist,"reg_type") = "alr_yx_reg"
  return(reslist) 
}
