mlm <-
function(Y,X){ 
  B = solve(crossprod(X),crossprod(X,Y),tol=1e-21)
  return(B)
}
