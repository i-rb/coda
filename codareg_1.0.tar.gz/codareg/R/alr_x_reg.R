alr_x_reg <-
function(Y,X,Z=list(matrix()),R=list(NULL),constant=TRUE){
  
  if (constant){x_col_names = c("intercept")}
  else{x_col_names = c()}
  
  for (i in 1:length(X)){
    if (is.null(colnames(X[[i]]))){
      for (j in 1:(dim(X[[i]])[2])){
        x_col_names = c(x_col_names, paste("X_",i,"_",j,sep=""))
      }
    }
    else{x_col_names = c(x_col_names,colnames(X[[i]]))}
  }
  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      if (is.null(colnames(Z[[i]]))){
      for (j in 1:(dim(Z[[i]])[2])){
        x_col_names = c(x_col_names, paste("Z_",i,"_",j,sep=""))
      }
    }
      else{x_col_names = c(x_col_names,colnames(Z[[i]]))
      }
    }
  }
  
  if (is.null(colnames(Y))){
    y_col_names = c()
    for (i in 1:(dim(Y)[2])){
      y_col_names = c(y_col_names, paste("Y_",i,sep=""))
    }
  }
  else{y_col_names = colnames(Y)}
  
  ty = Y #already in coordinates
  if (is.null(R[[1]])){
    for (i in 1:length(X)){
      R[[i]] = dim(X[[i]])[2]
      X[[i]]=permutation_D(X[[i]],R[[i]])
    }
  }
  
  else{
    for (i in 1:length(X)){
      X[[i]]=permutation_D(X[[i]],R[[i]])
      }
    }
  
  tx = matrix(numeric(dim(X[[1]])[1]))+1 # here it is created a matrix which is a vector of ones (should be removed afterwords if constant=False)
  for (i in 1:length(X)){
    tx = cbind(tx,alr(X[[i]],dim(X[[i]])[2])) # the transformed X is created as a unique matrix
    }
  if (constant==FALSE){ # should remove the vector of zeros if no constant is required
    tx=tx[,-1]
    }
  if (!is.na(Z[[1]][1,1])){
    for (z in Z){
      tx=cbind(tx,z)
    }
  }
  
  if (sum(is.na(ty))>0){stop("There are NAs in the Y variable.")}
  if (sum(is.na(tx))>0){stop("There are NAs in the X variable.")}

  Bstar = mlm(ty,tx)
  bcov = b_cov(tx,ty,Bstar)
  Bs = t(matrix(numeric(dim(Y)[2])))

  h=1
  if (constant==TRUE){
    h=2
    b0=Bstar[1,]
    Bs=rbind(Bs, Bstar[1,])
  }
  xdimlist=list()
  for (i in 1:length(X)){
    if (is.null(attr(X[[i]],"space"))){dimx = dim(X[[i]])[2]}  
    if (!is.null(attr(X[[i]],"space"))){
      if (attr(X[[i]],"space")=="simplex"){
        dimx = dim(X[[i]])[2]
      }
      else{dimx = dim(X[[i]])[2]+1}
    }
    xdimlist[i] = dimx
    if (h==(h+dimx-2)){matrix_x = t(matrix(Bstar[h,]))}
    if (h!=(h+dimx-2)){matrix_x = Bstar[h:(h+dimx-2),] }
    B_q = t(matrix_x)%*%F_D(dimx)
    B_q = inv_permutation_D(B_q, R[[i]])
    B_q = closure(exp(B_q))
    Bs= rbind(Bs, t(B_q))
    h=h+dimx-1
  }

  if (!is.na(Z[[1]][1,1])){
    for (i in 1:length(Z)){
      dimz = dim(Z[[i]])[2]
      if (h==(h+dimz-1)){matrix_z = t(matrix(Bstar[h,]))}
      if (h!=(h+dimz-1)){matrix_z = Bstar[h:(h+dimz-1),]} # it is non comp, it does not lose a dimension in the transformation
      h=h+dimz
      c_k = as.matrix(matrix_z)
      Bs = rbind(Bs, c_k)
    }
  }
  Bs = as.matrix(Bs[-1,])
  attr(Bstar,"space")="alr_coord"
  attr(Bstar,"reference") = R
  
  attr(tx,"space") = "alr_coord"
  attr(tx,"reference") = R
  
  Bs = as.matrix(Bs)
  
  colnames(Bs) = y_col_names
  rownames(Bs) = x_col_names
  attr(Bs,"space")="simplex"
  
  fittedvalues = tx%*%Bstar
  resid = ty- fittedvalues
  attr(resid,"space") = NULL
  attr(resid,"contrast") = NULL
  
  reslist = list(Y_coord = ty, X_coord = tx, constant = constant, B_coord = Bstar, B_simplex = Bs , Bcoord_cov=bcov, fitted_v_coord = fittedvalues, residuals_coord = resid, xdim=xdimlist)
  attr(reslist,"reg_type") = "alr_x_reg"
  return(reslist) 
}
