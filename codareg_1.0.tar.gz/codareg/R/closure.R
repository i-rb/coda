closure <-
function(x, k){ 
  if (missing(k)){
    newx <- (x)/rowSums(x)
    return(newx)
  }
  else{
    newx <- (k*x)/rowSums(x)
    return(newx)
  }
}
